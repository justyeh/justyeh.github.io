exports.jwtSecret = 'justyeh'

exports.apiWhiteList = ['/api/','/api/user/login','/api/postComment','/api/comment/add']
